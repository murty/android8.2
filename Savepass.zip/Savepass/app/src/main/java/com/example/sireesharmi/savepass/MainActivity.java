package com.example.sireesharmi.savepass;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText userme;
    private EditText passme;
    private Button saveme;

    @Override
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userme = (EditText) findViewById(R.id.user);
        passme = (EditText) findViewById(R.id.pass);
        saveme = (Button) findViewById(R.id.saveme);
        saveme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String key = userme.getText().toString();
                String value = passme.getText().toString();
                if (key.length() <= 0 || value.toString().length() <= 0) {
                    Toast.makeText(MainActivity.this, "please fill all", Toast.LENGTH_SHORT).show();
                    return;
                }
                saveSharedpref(userme.getText().toString(), passme.getText().toString(), MainActivity.this);
                Toast.makeText(MainActivity.this, "Saved", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void saveSharedpref(String key, String value, Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("my data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        Toast.makeText(MainActivity.this, "Saved", Toast.LENGTH_SHORT).show();
        editor.commit();
    }


}